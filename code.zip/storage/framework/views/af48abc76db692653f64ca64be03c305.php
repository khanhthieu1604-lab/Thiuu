

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-10">
    <div class="mb-8">
        <h2 class="text-2xl font-bold dark:text-white uppercase tracking-wider">Quản lý Đơn thuê xe</h2>
        <p class="text-gray-500 text-sm">Xem và phê duyệt các yêu cầu đặt xe từ khách hàng</p>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-xl overflow-hidden border dark:border-gray-700">
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-300 uppercase text-xs font-black">
                    <tr>
                        <th class="px-6 py-4">Mã Đơn</th>
                        <th class="px-6 py-4">Khách hàng</th>
                        <th class="px-6 py-4">Thông tin xe</th>
                        <th class="px-6 py-4">Thời gian thuê</th>
                        <th class="px-6 py-4">Tổng tiền</th>
                        <th class="px-6 py-4">Trạng thái</th>
                        <th class="px-6 py-4 text-center">Thao tác</th>
                    </tr>
                </thead>
                <tbody class="divide-y dark:divide-gray-700">
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition text-sm">
                        <td class="px-6 py-4 font-bold text-blue-600">#<?php echo e($booking->id); ?></td>
                        <td class="px-6 py-4">
                            <div class="dark:text-white font-semibold"><?php echo e($booking->user->name); ?></div>
                            <div class="text-[10px] text-gray-400"><?php echo e($booking->user->phone); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="dark:text-white"><?php echo e($booking->vehicle->name); ?></div>
                            <div class="text-[10px] text-gray-400 font-bold uppercase"><?php echo e($booking->vehicle->brand); ?></div>
                        </td>
                        <td class="px-6 py-4 text-xs text-gray-500 dark:text-gray-400">
                            <?php echo e($booking->start_date->format('d/m/Y')); ?> - <?php echo e($booking->end_date->format('d/m/Y')); ?>

                        </td>
                        <td class="px-6 py-4 font-black text-gray-900 dark:text-white">
                            <?php echo e(number_format($booking->total_price)); ?>đ
                        </td>
                        <td class="px-6 py-4">
                            <?php
                                $statusClasses = [
                                    'pending' => 'bg-yellow-100 text-yellow-700',
                                    'confirmed' => 'bg-green-100 text-green-700',
                                    'cancelled' => 'bg-red-100 text-red-700',
                                    'completed' => 'bg-blue-100 text-blue-700',
                                ];
                            ?>
                            <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase <?php echo e($statusClasses[$booking->status]); ?>">
                                <?php echo e($booking->status); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <form action="<?php echo e(route('admin.bookings.update_status', $booking->id)); ?>" method="POST" class="inline-flex gap-2">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <select name="status" onchange="this.form.submit()" class="text-xs border-gray-300 rounded dark:bg-gray-700 dark:text-white">
                                    <option value="pending" <?php echo e($booking->status == 'pending' ? 'selected' : ''); ?>>Chờ duyệt</option>
                                    <option value="confirmed" <?php echo e($booking->status == 'confirmed' ? 'selected' : ''); ?>>Xác nhận</option>
                                    <option value="completed" <?php echo e($booking->status == 'completed' ? 'selected' : ''); ?>>Hoàn thành</option>
                                    <option value="cancelled" <?php echo e($booking->status == 'cancelled' ? 'selected' : ''); ?>>Hủy đơn</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-10 text-center text-gray-500 italic">Chưa có đơn hàng nào được đặt.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="mt-6 flex justify-center">
        <?php echo e($bookings->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\NEWPROJECT\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>